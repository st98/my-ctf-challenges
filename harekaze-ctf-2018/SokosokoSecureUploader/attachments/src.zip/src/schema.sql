CREATE TABLE decryption_key (
  id text NOT NULL PRIMARY KEY,
  key text NOT NULL
);